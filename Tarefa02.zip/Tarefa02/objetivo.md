Tarefa 2:
A base de dados utilizada será a USPS e os modelos serão fusionART, fuzzyART, e fuzzyARTMAP.
1. Embaralhar os dados e treinar os modelos usando as metrícas ACC para supervisionado e ARI para não supervisionado.
  - Não tem como usar o ACC no shuffle
2. Aplicar o VAT nos dados e treinar os modelos usando as metrícas ACC para supervisionado e ARI para não supervisionado.
3. Separar em classes e treinar o modelo e usar as métricas FWT, BWT e ACC
4. Plotar comportamento do modelo conforme as classes são apresentadas